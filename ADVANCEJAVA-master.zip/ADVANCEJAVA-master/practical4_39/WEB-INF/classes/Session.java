import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.Date;
public class Session extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		HttpSession ses=req.getSession(true);
			PrintWriter out=res.getWriter();
		if(ses  == null)
		{
				out.println("Session not availble");
		}
		else
		{


		if(req.getParameter("user").equals(ses.getAttribute("user")))
		{
					out.println((Integer)ses.getAttribute("count") + 1);
					ses.setAttribute("count",(Integer)ses.getAttribute("count") + 1 );
					out.println(new Date(ses.getLastAccessedTime()));
					out.println(ses.getId());
		}
		else
		{
			ses.setAttribute("user",req.getParameter("user"));
			out.println(1);
			out.println(new Date(ses.getLastAccessedTime()));
					out.println(ses.getId());
			ses.setAttribute("count", 1 );
		}}
		out.close();
	}
}