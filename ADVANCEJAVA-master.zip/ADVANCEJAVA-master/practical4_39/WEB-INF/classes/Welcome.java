import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class Welcome extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		Cookie cl[]=req.getCookies();
		int count=1;
		for(int i=0;i<cl.length;i++)
		{
				if(req.getParameter("user").equals(cl[i].getName()))
				{
					PrintWriter out=res.getWriter();
					out.println("User : "+req.getParameter("user")+"Count" + cl[i].getValue());
					out.close();
					break;
				}
		}

	}
}