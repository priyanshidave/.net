import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class Count extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		Cookie cl[]=req.getCookies();
		int count=1;
		if(cl != null)
		{
		for(int i=0;i<cl.length;i++)
		{
				if(req.getParameter("user").equals(cl[i].getName()))
				{
					count++;
					break;
				}
		}}
		Cookie ck=new Cookie(req.getParameter("user"),Integer.toString(count));
		res.addCookie(ck);
		res.sendRedirect("Welcome?user="+req.getParameter("user"));
	}
}