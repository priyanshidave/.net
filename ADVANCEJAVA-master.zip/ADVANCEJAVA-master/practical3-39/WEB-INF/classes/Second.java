import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class Second extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		ServletContext con=getServletContext();
		String ouser=con.getInitParameter("username");
		String opass=con.getInitParameter("password");
		PrintWriter out=res.getWriter();
		out.println(ouser);
		out.println(opass);

		res.setContentType("text/html");
		String user=req.getParameter("user");
		String pass=req.getParameter("pass");
		if(user.compareTo(ouser)==0 && pass.compareTo(opass)==0)
		{
			res.sendRedirect("Welcome?user="+user);
		}
		else
		{
			res.sendRedirect("login.html");
		}

	}

}