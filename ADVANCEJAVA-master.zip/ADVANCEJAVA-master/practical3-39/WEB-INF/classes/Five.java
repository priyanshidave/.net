import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Five extends HttpServlet
{

	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		res.setIntHeader("Refresh", 2);

		PrintWriter out=res.getWriter();
		out.println(java.time.LocalTime.now());
	}
}