import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class First extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		PrintWriter out=res.getWriter();
		String color =getInitParameter("color");
		String user=req.getParameter("username");
		res.setContentType("text/html");
		out.println("<html><body style=background-color:"+color+"><center><h1>welcome : "+user+ " </h1></center><body></html>");
	}
}