import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class Third extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{

		String ouser=getInitParameter("username");
		String opass=getInitParameter("password");
		PrintWriter out=res.getWriter();


		res.setContentType("text/html");
		String user=req.getParameter("user");
		String pass=req.getParameter("pass");
		if(user.compareTo(ouser)==0 && pass.compareTo(opass)==0)
		{
			RequestDispatcher rd=req.getRequestDispatcher("Welcome");
			rd.forward(req,res);
		}
		else
		{
			out.println("Username or Password Incoorect");
			RequestDispatcher rd=req.getRequestDispatcher("login.html");
			rd.include(req,res);
		}

	}

}