import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class Four extends HttpServlet
{
	private static int count ;
	public void init()
	{
		count=0;
	}
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		count++;
		PrintWriter out=res.getWriter();
		out.println(count);
		out.println(req.getRequestURI());
		out.println(req.getHeader("x-forwarded-proto"));

	}
}