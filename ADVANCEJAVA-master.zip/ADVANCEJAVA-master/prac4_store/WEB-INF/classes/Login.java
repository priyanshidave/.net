import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class Login extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		String user=req.getParameter("user");
		String opass=getInitParameter(user);
		PrintWriter out=res.getWriter();

		res.setContentType("text/html");

		String pass=req.getParameter("pass");
		if(pass.equals(opass))
		{
			HttpSession ses =req.getSession();
			ses.setAttribute("user",user);
			res.sendRedirect("productlist.html");

		}
		else
		{
			out.println("Username or Password Incoorect");
			RequestDispatcher rd=req.getRequestDispatcher("login.html");
			rd.include(req,res);
		}

	}

}